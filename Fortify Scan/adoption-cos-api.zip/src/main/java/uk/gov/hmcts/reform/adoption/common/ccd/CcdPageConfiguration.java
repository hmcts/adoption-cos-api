package uk.gov.hmcts.reform.adoption.common.ccd;

public interface CcdPageConfiguration {
    void addTo(final PageBuilder pageBuilder);
}
