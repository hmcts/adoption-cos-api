package uk.gov.hmcts.reform.adoption.document.content;

public final class DocmosisTemplateConstants {

    public static final String SAMPLE_TEMPLATE = "sampleTemplate";

    private DocmosisTemplateConstants() {
    }
}
