package uk.gov.hmcts.reform.adoption.notification;

public enum EmailTemplateName {
    SAVE_SIGN_OUT,
    TEST_EMAIL
}
